### Hexlet tests and linter status:
[![Actions Status](https://github.com/GrigoriyKruchinin/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/GrigoriyKruchinin/python-project-49/actions)

My project:

[![Maintainability](https://api.codeclimate.com/v1/badges/a52f66fd43a393dea0a7/maintainability)](https://codeclimate.com/github/GrigoriyKruchinin/python-project-49/maintainability)

[![asciicast](https://asciinema.org/a/GnUw7CJrrHioZR8RyE27sPYsw.svg)](https://asciinema.org/a/GnUw7CJrrHioZR8RyE27sPYsw)
