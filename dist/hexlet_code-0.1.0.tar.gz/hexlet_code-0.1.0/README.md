### Hexlet tests and linter status:
[![Actions Status](https://github.com/GrigoriyKruchinin/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/GrigoriyKruchinin/python-project-49/actions)

My project:
#Codeclimate
[![Maintainability](https://api.codeclimate.com/v1/badges/a52f66fd43a393dea0a7/maintainability)](https://codeclimate.com/github/GrigoriyKruchinin/python-project-49/maintainability)
#brain-even
[![asciicast](https://asciinema.org/a/586428.svg)](https://asciinema.org/a/586428)
#brain-calc
[![asciicast](https://asciinema.org/a/RTuEh76qglwZcGSsVLlhM3eyI.svg)](https://asciinema.org/a/RTuEh76qglwZcGSsVLlhM3eyI)
